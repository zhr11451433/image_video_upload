package router

import (
	"context"
	"image_upload/commons/store"
	"image_upload/services/upload"

	"github.com/gin-gonic/gin"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

func SetRouter() *gin.Engine {
	//本地存储
	localStorage := store.NewLocalStore()

	r := gin.Default()
	r.Static("./uploads", "./uploads")
	r.GET("/", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})
	//图片本地
	localImages := upload.NewImageStore(localStorage)
	localImageSvc := upload.NewImageService(localImages)
	{
		r.POST("/images", localImageSvc.UploadImage())
		r.POST("/images/*key", localImageSvc.DeleteImage())
		r.GET("/images/*key", localImageSvc.OpenImage())
	}
	//视频本地
	localVideos := upload.NewVideoStore(localStorage)
	localVideoSvc := upload.NewVideoService(localVideos)
	{
		r.POST("/videos", localVideoSvc.UploadVideo())
		r.POST("/videos/*key", localVideoSvc.DeleteVideo())
		r.GET("/videos/*key", localVideoSvc.OpenVideo())
	}
	//minio存储
	creds := credentials.NewStaticV4(store.AccessKey, store.SecretKey, "")
	ctx := context.Background()
	minioStorage, err := store.NewMinioStore(
		ctx,
		"localhost:9000",
		"demo1",
		false,
		creds,
	)
	if err != nil {
		panic(err)
	}
	return r
}
